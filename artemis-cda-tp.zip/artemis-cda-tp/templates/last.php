<section class="py-8">
    <div class="container px-4 mx-auto">
        <div class="flex flex-wrap -m-4">
            <?php
                include_once __DIR__ . '/_partials/last_books.php';
                include_once __DIR__ . '/_partials/last_clients.php';
                include_once __DIR__ . '/_partials/last_loans.php';
            ?>
        </div>
    </div>
</section>