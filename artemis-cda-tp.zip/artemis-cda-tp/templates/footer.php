</div>
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<script src="js/charts-demo.js"></script>
</body>

</html>